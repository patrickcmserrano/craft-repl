@echo off
chcp 65001 >nul
echo ========================================================
echo    🌌 Instalador do Céu Alienígena (Pace ^& Lizzie)
echo ========================================================
echo.

set "MC_DIR=%APPDATA%\.minecraft"

if not exist "%MC_DIR%" (
    echo [!] Pasta .minecraft padrão não encontrada em %APPDATA%.
    echo Tentando detectar diretório do SKlauncher ou launcher customizado...
    set /p "CUSTOM_DIR=Digite o caminho da sua pasta .minecraft (ou feche para cancelar): "
    if not exist "%CUSTOM_DIR%" (
        echo [ERRO] Pasta não encontrada!
        pause
        exit /b 1
    )
    set "MC_DIR=%CUSTOM_DIR%"
)

echo [+] Instalando mod de auto-sincronização em %MC_DIR%\mods...
if not exist "%MC_DIR%\mods" mkdir "%MC_DIR%\mods"
copy /Y "mods\alien-sky-sync-1.0.0.jar" "%MC_DIR%\mods\" >nul

echo [+] Instalando shaderpack do Céu Alienígena em %MC_DIR%\shaderpacks...
if not exist "%MC_DIR%\shaderpacks" mkdir "%MC_DIR%\shaderpacks"
copy /Y "shaderpacks\MakeUp-UltraFast-AlienSky.zip" "%MC_DIR%\shaderpacks\" >nul

echo.
echo ========================================================
echo  ✅ Instalação concluída com sucesso!
echo.
echo  IMPORTANTE:
echo  Se o Minecraft já estiver aberto, FECHE e ABRA NOVAMENTE.
echo  (O Fabric só carrega novos mods na inicialização do jogo).
echo.
echo  Ao entrar no mundo, uma mensagem roxa no chat avisará:
echo  "Shaders sincronizados com o servidor!"
echo ========================================================
echo.
pause
