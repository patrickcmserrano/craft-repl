#!/usr/bin/env bash
set -e
MC_DIR="$HOME/.minecraft"
echo "========================================================"
echo "   🌌 Instalador do Céu Alienígena (Linux)"
echo "========================================================"
mkdir -p "$MC_DIR/mods" "$MC_DIR/shaderpacks"
cp -v mods/alien-sky-sync-1.0.0.jar "$MC_DIR/mods/"
cp -v shaderpacks/MakeUp-UltraFast-AlienSky.zip "$MC_DIR/shaderpacks/"
echo ""
echo "✅ Pronto! Ao entrar no servidor, os shaders sincronizam sozinhos via TCP."
