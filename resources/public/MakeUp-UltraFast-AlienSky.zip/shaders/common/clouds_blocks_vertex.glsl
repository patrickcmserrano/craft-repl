#include /lib/config.glsl
void main() {
    #if ALIEN_CLOUD_MODE != 2
        gl_Position = vec4(0.0, 0.0, -2.0, 1.0);
        return;
    #endif
}
