/*
 * Alien Sky Ephemeris & Ray-Plane Analytical Geometry
 * Fabric 1.21.1 / Iris / MakeUp-UltraFast
 * Synchronized with craft.agents.astrophysics.ephemeris (CA-050)
 */

#ifndef ALIEN_SKY_GLSL
#define ALIEN_SKY_GLSL

// Hash for procedural pseudo-randomness (GLSL 120 compliant)
float hash31(vec3 p) {
    vec3 q = fract(p * 0.3183099 + vec3(0.1, 0.1, 0.1));
    q *= 17.0;
    return fract(q.x * q.y * q.z * (q.x + q.y + q.z));
}

// 1. Procedural HR-Diagram Starfield (15,000+ deterministic stars with Planck color)
vec3 computeStarfield(vec3 rayDir, float time, float nightMix) {
    if (nightMix <= 0.001 || rayDir.y <= 0.005) return vec3(0.0);

    // Kasten-Young airmass approximation near horizon
    float zenithAngle = max(0.0, rayDir.y);
    float airmass = 1.0 / (zenithAngle + 0.05);
    float extinction = exp(-airmass * 0.08);

    // Celestial grid partitioning
    vec3 grid = floor(rayDir * 180.0);
    vec3 f = fract(rayDir * 180.0) - 0.5;
    float h = hash31(grid);

    vec3 stars = vec3(0.0);
    if (h > 0.980) {
        vec3 offset = (vec3(hash31(grid + 1.0), hash31(grid + 2.0), hash31(grid + 3.0)) - 0.5) * 0.7;
        float d = length(f - offset);
        float starIntensity = smoothstep(0.12, 0.0, d) * pow((h - 0.980) / 0.020, 2.0);

        // Planck Blackbody classification (Salpeter IMF distribution)
        vec3 starColor;
        if (h > 0.996) {
            // O/B Blue Supergiant (~25,000K)
            starColor = vec3(0.65, 0.82, 1.0);
        } else if (h > 0.990) {
            // G/F Sun-like (~6,000K)
            starColor = vec3(1.0, 0.96, 0.88);
        } else {
            // M/K Red-Amber Dwarf (~3,000K with TiO attenuation)
            starColor = vec3(1.0, 0.62, 0.35);
        }

        // Scintillation / Atmospheric twinkle
        float twinkle = 0.85 + 0.15 * sin(time * 0.06 + h * 75.0);
        stars = starColor * starIntensity * extinction * twinkle * 2.8;
    }

    return stars * nightMix;
}

// 2. Galactic Nebula Dust Band (Perlin harmonic swirl along galactic plane)
vec3 computeGalacticNebula(vec3 rayDir, float nightMix) {
    if (nightMix <= 0.001 || rayDir.y <= 0.0) return vec3(0.0);

    // Galactic Pole inclined 58 degrees
    vec3 galPole = normalize(vec3(-0.50, 0.78, 0.38));
    float distToGalPlane = abs(dot(rayDir, galPole));

    // Gaussian core of the Milky Way / Alien galactic disc
    float galBand = exp(-distToGalPlane * distToGalPlane * 22.0);
    if (galBand < 0.01) return vec3(0.0);

    // Swirling cosmic dust filaments
    float s1 = sin(rayDir.x * 5.0 + rayDir.y * 3.5) * cos(rayDir.z * 4.5);
    float s2 = sin(rayDir.y * 9.0 - rayDir.z * 6.5 + s1 * 1.8);
    float swirl = galBand * (0.55 + 0.45 * s2);

    // Vibrant Aurora Nebula Palette: Emerald green, electric cyan, celestial gold
    vec3 colEmerald = vec3(0.08, 0.82, 0.48);
    vec3 colCyberCyan = vec3(0.12, 0.88, 0.95);
    vec3 colCelestialGold = vec3(0.95, 0.68, 0.18);

    vec3 nebColor = mix(colEmerald, colCyberCyan, s1 * 0.5 + 0.5);
    nebColor = mix(nebColor, colCelestialGold, max(0.0, s2) * 0.5);

    float horizonAtten = smoothstep(0.0, 0.15, rayDir.y);
    return nebColor * swirl * nightMix * horizonAtten * 1.35;
}

// 3. Analytical Ray-Plane & Gas Giant Surface Engine
// Synchronized with CA-050 ephemeris: 84000 ticks period, 28 deg inclination
vec3 renderAlienSky(vec3 baseSky, vec3 rayDir, vec3 sunDir, int tickTime, float rain) {
    if (rain > 0.99) return baseSky; // Overcast storm suppresses outer celestial bodies

    float t = float(tickTime);
    float orbitalPeriod = 84000.0; // 3.5 Minecraft days
    float theta = 6.283185307 * (mod(t, orbitalPeriod) / orbitalPeriod);
    float inc = 28.0 * 0.0174532925;

    // Resonant Gas Giant World Vector
    vec3 gasGiantDir = normalize(vec3(cos(theta), sin(theta) * cos(inc), sin(theta) * sin(inc)));

    // Planetary rotation axis & ring normal
    vec3 ringNormal = normalize(vec3(0.26, 0.93, 0.24));

    // Gas Giant Apparent Angular Radius
    float R0 = 0.088; // ~5.0 degrees angular radius (impressive alien titan)
    float R_in = 1.35; // Ring inner radius in planet radii
    float R_out = 2.45; // Ring outer radius in planet radii

    // Night/Day atmospheric blend factor
    float nightMix = smoothstep(0.18, -0.15, sunDir.y);

    // Background Starfield & Nebula
    vec3 skyColor = baseSky;
    skyColor += computeGalacticNebula(rayDir, nightMix);
    skyColor += computeStarfield(rayDir, t, nightMix);

    // Celestial Horizon Attenuation
    float horizonMask = smoothstep(-0.02, 0.08, rayDir.y);
    if (horizonMask <= 0.001) return skyColor;

    // Gas Giant Disc Test
    float dotG = dot(rayDir, gasGiantDir);
    bool hitPlanet = false;
    vec3 planetColor = vec3(0.0);
    float planetAlpha = 0.0;
    float zSurf = 0.0;

    vec3 vx = normalize(cross(ringNormal, gasGiantDir));
    vec3 vy = normalize(cross(gasGiantDir, vx));

    if (dotG > 0.0) {
        vec3 vPerp = rayDir - dotG * gasGiantDir;
        float rho = length(vPerp) / R0;
        if (rho < 1.0) {
            hitPlanet = true;
            zSurf = sqrt(max(0.0, 1.0 - rho * rho));
            float u = dot(vPerp, vx) / R0;
            float v = dot(vPerp, vy) / R0;

            // Surface normal on unit sphere facing camera
            vec3 N = u * vx + v * vy - zSurf * gasGiantDir;
            vec3 P_surf = N;

            // Ring Shadow on Planet Atmosphere (Analytical Ray-Plane test)
            float ringShadow = 1.0;
            float denom = dot(sunDir, ringNormal);
            if (abs(denom) > 0.001) {
                float tPlane = -dot(P_surf, ringNormal) / denom;
                if (tPlane > 0.0) {
                    vec3 hitP = P_surf + sunDir * tPlane;
                    float rShadow = length(hitP);
                    if (rShadow >= R_in && rShadow <= R_out) {
                        float normR = (rShadow - R_in) / (R_out - R_in);
                        // Cassini Division gap in shadow
                        float cassini = smoothstep(0.03, 0.07, abs(normR - 0.62));
                        float ringDensity = (sin(normR * 48.0) * 0.5 + 0.5) * 0.75 + 0.25;
                        ringShadow = mix(1.0, 0.14, ringDensity * cassini);
                    }
                }
            }

            // Atmospheric Zonal Bands & Differential Flow
            float sinLat = dot(P_surf, ringNormal);
            float lat = asin(clamp(sinLat, -1.0, 1.0));
            float windFlow = sin(lat * 16.0 + t * 0.003) * 0.22;
            float bandPattern = sin(lat * 30.0 + windFlow);
            float microBands = sin(lat * 90.0);

            // Dramatic Cosmic Amethyst & Golden Rose Banding
            vec3 royalAmethyst = vec3(0.38, 0.05, 0.52);
            vec3 neonRose = vec3(0.92, 0.12, 0.58);
            vec3 celestialGold = vec3(1.0, 0.85, 0.32);

            vec3 albedo = mix(royalAmethyst, neonRose, bandPattern * 0.5 + 0.5);
            albedo = mix(albedo, celestialGold, smoothstep(0.35, 0.65, microBands * 0.5 + 0.5) * 0.40);

            // Lighting & Terminator
            float NdotL = dot(N, sunDir);
            float daylight = smoothstep(-0.14, 0.20, NdotL) * ringShadow;

            // Night-side electrical storm bioluminescence (Violet/Magenta lightning)
            vec3 nightBiolum = pow(albedo, vec3(2.2)) * vec3(0.45, 0.10, 0.85) * 0.45;

            // Atmospheric Rayleigh Scattering Rim (Intense Electric Ultraviolet & Neon Magenta)
            float fresnel = pow(1.0 - zSurf, 2.8);
            vec3 sunsetTint = mix(vec3(1.0, 0.18, 0.60), vec3(0.60, 0.15, 1.0), clamp(NdotL + 0.3, 0.0, 1.0));
            vec3 rimGlow = sunsetTint * fresnel * 2.8 * smoothstep(-0.30, 0.35, NdotL);

            planetColor = mix(nightBiolum, albedo, daylight) + rimGlow;
            planetAlpha = smoothstep(1.0, 0.97, rho);
        }
    }

    // Analytical Ray-Ring Intersection
    bool hitRing = false;
    vec3 ringColor = vec3(0.0);
    float ringAlpha = 0.0;
    bool ringInFront = false;

    float denomRing = dot(rayDir, ringNormal);
    if (abs(denomRing) > 0.0001) {
        // Distance to ring plane
        float tRing = (dot(gasGiantDir, ringNormal) / (R0 * denomRing));
        if (tRing > 0.0) {
            vec3 hitPointRing = tRing * rayDir;
            vec3 displacement = hitPointRing - (gasGiantDir / R0);
            float rRing = length(displacement);

            if (rRing >= R_in && rRing <= R_out) {
                hitRing = true;
                ringInFront = (tRing < (1.0 / R0));

                // Analytical Planet Shadow on Rings
                float RdotL = dot(displacement, sunDir);
                float shadowOnRing = 1.0;
                if (RdotL < 0.0) {
                    float cylDist = length(displacement - RdotL * sunDir);
                    shadowOnRing = smoothstep(0.95, 1.05, cylDist);
                }

                // Ring texture, Cassini division & opacity
                float normR = (rRing - R_in) / (R_out - R_in);
                float cassini = smoothstep(0.03, 0.065, abs(normR - 0.62));
                float ringlets = (sin(normR * 125.0) * 0.5 + 0.5) * (sin(normR * 38.0) * 0.5 + 0.5);

                float density = (0.42 + 0.48 * ringlets) * cassini;
                float edgeFade = smoothstep(R_in, R_in + 0.04, rRing) * smoothstep(R_out, R_out - 0.04, rRing);
                ringAlpha = density * edgeFade;

                // Golden Platinum ring backscattering
                float phaseTerm = 0.65 + 0.35 * pow(abs(dot(rayDir, sunDir)), 2.0);
                vec3 ringIcyColor = mix(vec3(1.0, 0.88, 0.62), vec3(0.85, 0.68, 0.95), normR);
                ringColor = ringIcyColor * shadowOnRing * phaseTerm * 1.25;
            }
        }
    }

    // Combine Planet and Rings with Depth Testing
    vec3 celestialComposite = vec3(0.0);
    float celestialAlpha = 0.0;

    if (hitPlanet && hitRing) {
        if (ringInFront) {
            // Ring passes in front of planet disc
            celestialComposite = mix(planetColor, ringColor, ringAlpha);
            celestialAlpha = planetAlpha;
        } else {
            // Planet occludes ring behind it
            celestialComposite = mix(ringColor, planetColor, planetAlpha);
            celestialAlpha = max(planetAlpha, ringAlpha);
        }
    } else if (hitPlanet) {
        celestialComposite = planetColor;
        celestialAlpha = planetAlpha;
    } else if (hitRing) {
        celestialComposite = ringColor;
        celestialAlpha = ringAlpha;
    }

    // Apply Celestial Body over Sky with Horizon Fade and Rain Attenuation
    float finalBlend = celestialAlpha * horizonMask * (1.0 - rain * 0.85);
    return mix(skyColor, celestialComposite, finalBlend);
}

#endif // ALIEN_SKY_GLSL
