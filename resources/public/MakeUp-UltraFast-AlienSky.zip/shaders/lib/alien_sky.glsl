/*
 * Sovereign Alien Sky Astrophysics & Ray-Plane Analytical Geometry (ULTRA-FAST 60+ FPS)
 * Fabric 1.21.1 / Iris / MakeUp-UltraFast (CA-053 Optimized)
 * Colossal Spiral Galaxy, Volumetric Auroras & Ringed Gas Giant
 */

#ifndef ALIEN_SKY_GLSL
#define ALIEN_SKY_GLSL

uniform float frameTimeCounter;

// ============================================================================
// 1. PRIMITIVAS DE RUIDO ULTRA-OTIMIZADAS (Fast Hash + 3-Octave FBM)
// ============================================================================
float hash31(vec3 p) {
    p = fract(p * 0.1031);
    p += dot(p, p.yzx + 33.33);
    return fract((p.x + p.y) * p.z);
}

float fastNoise3D(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    vec3 u = f * f * (3.0 - 2.0 * f);

    float n000 = hash31(i);
    float n100 = hash31(i + vec3(1.0, 0.0, 0.0));
    float n010 = hash31(i + vec3(0.0, 1.0, 0.0));
    float n110 = hash31(i + vec3(1.0, 1.0, 0.0));
    float n001 = hash31(i + vec3(0.0, 0.0, 1.0));
    float n101 = hash31(i + vec3(1.0, 0.0, 1.0));
    float n011 = hash31(i + vec3(0.0, 1.0, 1.0));
    float n111 = hash31(i + vec3(1.0, 1.0, 1.0));

    return mix(
        mix(mix(n000, n100, u.x), mix(n010, n110, u.x), u.y),
        mix(mix(n001, n101, u.x), mix(n011, n111, u.x), u.y),
        u.z
    );
}

// 3 octavas leves com rotacoes analiticas (sem loops pesados)
float fbm3(vec3 p) {
    float v = 0.52 * fastNoise3D(p);
    p = p * 2.05 + vec3(7.1, 3.3, 1.7);
    v += 0.32 * fastNoise3D(p);
    p = p * 2.04 + vec3(2.5, 8.4, 5.2);
    v += 0.16 * fastNoise3D(p);
    return v;
}

// ============================================================================
// 2. CAMPO ESTELAR FOTOMETRICO LEVE (Diagrama HR + Planck + Scintillation)
// ============================================================================
vec3 blackbodyColor(float h) {
    if (h < 0.55) return mix(vec3(1.0, 0.38, 0.18), vec3(1.0, 0.72, 0.45), h / 0.55);
    if (h < 0.85) return mix(vec3(1.0, 0.72, 0.45), vec3(0.95, 0.97, 1.0), (h - 0.55) / 0.30);
    return mix(vec3(0.95, 0.97, 1.0), vec3(0.45, 0.75, 1.0), (h - 0.85) / 0.15);
}

vec3 renderPhotometricStarfield(vec3 rd, float uTime) {
    vec3 stars = vec3(0.0);
    // 2 camadas otimizadas: fundo denso e gigantes brilhantes
    for (int layer = 0; layer < 2; layer++) {
        float scale = (layer == 0) ? 90.0 : 40.0;
        vec3 p = rd * scale;
        vec3 id = floor(p);
        vec3 f = fract(p) - 0.5;

        float rnd = hash31(id + float(layer) * 71.3);
        if (rnd > 0.80) {
            vec3 offset = (vec3(hash31(id + 1.0), hash31(id + 2.0), hash31(id + 3.0)) - 0.5) * 0.65;
            float d = length(f - offset);
            float mag = pow((rnd - 0.80) / 0.20, 2.8);
            float radius = (layer == 0) ? 0.055 : 0.095;

            float horizonFactor = clamp(1.0 - rd.y, 0.2, 1.0);
            float twinkle = 0.80 + 0.20 * sin(uTime * 14.0 * horizonFactor + rnd * 62.8);

            float core = smoothstep(radius, 0.0, d) * mag * twinkle;
            float halo = exp(-d * ((layer == 0) ? 14.0 : 7.0)) * mag * 0.35;
            vec3 col = blackbodyColor(hash31(id + 9.7));
            stars += col * (core * 2.5 + halo);
        }
    }
    return stars;
}

// ============================================================================
// 3. GALAXIA ESPIRAL COLOSSAL OTIMIZADA (Warping Analitico + 1 Unico FBM)
// ============================================================================
vec3 renderColossalGalaxy(vec3 rd, float uTime) {
    vec3 galCenter = normalize(vec3(-0.45, 0.58, -0.67));
    vec3 galUp     = normalize(vec3(0.52, 0.74, 0.42));
    vec3 galRight  = normalize(cross(galCenter, galUp));
    vec3 galFwd    = cross(galUp, galRight);

    float gx = dot(rd - galCenter, galRight) * 2.1;
    float gy = dot(rd - galCenter, galFwd) * 0.85;

    float r = length(vec2(gx, gy));
    if (r > 1.65) return vec3(0.0);

    float theta = atan(gy, gx) + uTime * 0.015;

    float twist = 4.2 * log(max(r, 0.025));
    float armPhase1 = cos(2.0 * (theta - twist));
    float armPhase2 = cos(4.0 * (theta - twist * 0.85) + 1.2);

    // Deformacao analitica senoidal rapida + 1 unica chamada FBM3
    vec2 sinWarp = vec2(sin(gx * 3.2 + gy * 2.1), cos(gx * 2.4 - gy * 3.5)) * 0.28;
    vec3 noiseCoord = vec3(gx * 3.5 + sinWarp.x, gy * 3.5 + sinWarp.y, theta * 0.5);
    float warp = fbm3(noiseCoord);

    float armDensity = smoothstep(-0.3, 0.85, armPhase1 * 0.7 + armPhase2 * 0.3 + (warp - 0.5) * 0.9);
    float radialFalloff = exp(-r * 2.35) * (1.0 - smoothstep(1.1, 1.6, r));
    float diskEnvelope = armDensity * radialFalloff;

    // Bulbo central dourado
    float bulge = exp(-r * 7.5) * 1.65 + exp(-r * 2.8) * 0.45;
    vec3 bulgeColor = vec3(1.0, 0.88, 0.68) * bulge;

    // Bracos azuis OB
    vec3 armStarColor = mix(vec3(0.28, 0.58, 1.0), vec3(0.65, 0.42, 0.95), warp) * diskEnvelope * 1.35;

    // Regioes H-Alpha 656.3nm derivadas do mesmo warp (sem FBM extra!)
    float hAlphaNoise = smoothstep(0.55, 0.82, warp + 0.3 * sin(gx * 7.0 + gy * 6.5));
    float hAlphaZones = hAlphaNoise * smoothstep(0.2, 0.9, armPhase1) * radialFalloff;
    vec3 hAlphaColor  = vec3(1.0, 0.18, 0.55) * hAlphaZones * 2.4;

    // Faixas de poeira escura de Beer-Lambert derivadas do mesmo warp (sem FBM extra!)
    float dustRidge = 1.0 - abs(2.0 * warp - 1.0);
    float dustMask  = smoothstep(0.52, 0.90, pow(dustRidge, 2.0)) * exp(-r * 1.4);
    float transmittance = mix(1.0, 0.12, dustMask);

    vec3 galaxyRgb = (bulgeColor + armStarColor + hAlphaColor) * transmittance;
    galaxyRgb += vec3(0.45, 0.22, 0.35) * dustMask * bulge * 0.35;

    return max(galaxyRgb, vec3(0.0));
}

// ============================================================================
// 4. AURORAS VOLUMETRICAS OTIMIZADAS (6 Passos + Deformacao Global)
// ============================================================================
vec3 renderVolumetricAurora(vec3 rd, float uTime, float intensity) {
    if (rd.y <= 0.03 || intensity <= 0.01) return vec3(0.0);

    // Auroras concentradas predominantemente no Norte magnetico (-Z)
    float northMask = smoothstep(-0.4, 0.6, -rd.z);
    if (northMask <= 0.01) return vec3(0.0);

    vec3 accColor = vec3(0.0);
    const int STEPS = 6;
    vec2 baseUv = rd.xz / (rd.y + 0.22);
    
    // 1 unica amostra de ruido 3D para modular as dobras das cortinas
    float noiseFold = fastNoise3D(vec3(baseUv * 0.75, uTime * 0.08)) * 3.5;
    float ripple = sin(baseUv.x * 3.2 + uTime * 0.32) * 0.5;

    for (int i = 0; i < STEPS; i++) {
        float fi = float(i) / float(STEPS);
        float height = 1.0 + fi * 0.60;
        vec2 uv = baseUv * height;

        float wave = sin(uv.x * 2.8 + ripple + noiseFold);
        float curtain = exp(-abs(wave) * 4.6) * smoothstep(0.03, 0.28, rd.y) * (1.0 - smoothstep(0.52, 0.92, rd.y));

        vec3 auroraTint = mix(vec3(0.08, 0.96, 0.50), vec3(0.72, 0.18, 0.95), fi);
        accColor += auroraTint * curtain * (1.0 - fi * 0.4) * 0.24;
    }
    return accColor * intensity * northMask;
}

// ============================================================================
// 5. GIGANTE GASOSO + ANEIS COM AUTO-SOMBREAMENTO ANALITICO
// ============================================================================
float ringShadowAtPoint(vec3 localPos, vec3 lightDir, vec3 ringN, float rInner, float rOuter) {
    float denom = dot(lightDir, ringN);
    if (abs(denom) < 1e-4) return 1.0;
    float t = -dot(localPos, ringN) / denom;
    if (t <= 0.0) return 1.0;

    vec3 hit = localPos + lightDir * t;
    float d = length(hit);
    if (d >= rInner && d <= rOuter) {
        float u = (d - rInner) / (rOuter - rInner);
        float cassini = smoothstep(0.05, 0.12, abs(u - 0.58));
        float rings = (0.5 + 0.5 * sin(u * 52.0)) * (0.5 + 0.5 * sin(u * 190.0)) * cassini;
        return mix(1.0, 0.18, rings);
    }
    return 1.0;
}

// ============================================================================
// 6. COMPOSICAO FINAL DO CEU ALIENIGENA (GPU-FRIENDLY)
// ============================================================================
vec3 renderAlienSky(vec3 baseSky, vec3 rayDir, vec3 sunDir, int tickTime, float rain) {
    if (rain > 0.99) return baseSky;

    float t = float(tickTime);
    float uTime = (frameTimeCounter > 0.001) ? frameTimeCounter : (t * 0.05);

    // Efemeride do Gigante Gasoso (3.5 dias, inclinacao de 28 deg)
    float orbitalPeriod = 84000.0;
    float theta = 6.283185307 * (mod(t, orbitalPeriod) / orbitalPeriod);
    float inc = 28.0 * 0.0174532925;
    vec3 gasGiantDir = normalize(vec3(cos(theta), sin(theta) * cos(inc), sin(theta) * sin(inc)));
    vec3 ringNormal = normalize(vec3(0.22, 0.91, -0.35));

    float nightMix = smoothstep(0.18, -0.15, sunDir.y);
    float horizonMask = smoothstep(-0.02, 0.08, rayDir.y);

    vec3 skyColor = baseSky;

    if (horizonMask > 0.001) {
        // 1. Campo Estelar Fotometrico HR
        skyColor += renderPhotometricStarfield(rayDir, uTime) * nightMix * horizonMask;

        // 2. Galaxia Espiral Colossal (Majestosa a noite, nucleo visivel de dia)
        float galVisibility = mix(0.40, 1.35, nightMix);
        skyColor += renderColossalGalaxy(rayDir, uTime) * galVisibility * horizonMask;

        // 3. Auroras Volumetricas Leves (apenas a noite)
        if (nightMix > 0.01) {
            float auroraWave = sin(t * 0.00013089);
            float auroraInt = nightMix * max(0.0, auroraWave * auroraWave * 0.9);
            skyColor += renderVolumetricAurora(rayDir, uTime, auroraInt) * horizonMask;
        }
    }

    // 4. Gigante Gasoso e Aneis
    float dotG = dot(rayDir, gasGiantDir);
    float R0 = 0.095;
    float R_in = 1.35;
    float R_out = 2.50;

    bool hitPlanet = false;
    vec3 planetColor = vec3(0.0);
    float planetAlpha = 0.0;

    vec3 vx = normalize(cross(ringNormal, gasGiantDir));
    vec3 vy = normalize(cross(gasGiantDir, vx));

    if (dotG > 0.0) {
        vec3 vPerp = rayDir - dotG * gasGiantDir;
        float rho = length(vPerp) / R0;
        if (rho < 1.0) {
            hitPlanet = true;
            float zSurf = sqrt(max(0.0, 1.0 - rho * rho));
            float u = dot(vPerp, vx) / R0;
            float v = dot(vPerp, vy) / R0;

            vec3 N = u * vx + v * vy - zSurf * gasGiantDir;
            vec3 P_surf = N;

            float rShadow = ringShadowAtPoint(P_surf, sunDir, ringNormal, R_in, R_out);

            float sinLat = dot(P_surf, ringNormal);
            float lat = asin(clamp(sinLat, -1.0, 1.0));
            float windFlow = sin(lat * 16.0 + uTime * 0.05) * 0.22;
            float bandPattern = sin(lat * 30.0 + windFlow);
            float microBands = sin(lat * 90.0);

            vec3 royalAmethyst = vec3(0.38, 0.05, 0.52);
            vec3 neonRose = vec3(0.92, 0.12, 0.58);
            vec3 celestialGold = vec3(1.0, 0.85, 0.32);

            vec3 albedo = mix(royalAmethyst, neonRose, bandPattern * 0.5 + 0.5);
            albedo = mix(albedo, celestialGold, smoothstep(0.35, 0.65, microBands * 0.5 + 0.5) * 0.40);

            float NdotL = dot(N, sunDir);
            float daylight = smoothstep(-0.14, 0.20, NdotL) * rShadow;
            vec3 nightBiolum = pow(albedo, vec3(2.2)) * vec3(0.45, 0.10, 0.85) * 0.45;

            float fresnel = pow(1.0 - zSurf, 2.8);
            vec3 sunsetTint = mix(vec3(1.0, 0.18, 0.60), vec3(0.60, 0.15, 1.0), clamp(NdotL + 0.3, 0.0, 1.0));
            vec3 rimGlow = sunsetTint * fresnel * 2.8 * smoothstep(-0.30, 0.35, NdotL);

            planetColor = mix(nightBiolum, albedo, daylight) + rimGlow;
            planetAlpha = smoothstep(1.0, 0.97, rho);
        }
    }

    bool hitRing = false;
    vec3 ringColor = vec3(0.0);
    float ringAlpha = 0.0;
    bool ringInFront = false;

    float denomRing = dot(rayDir, ringNormal);
    if (abs(denomRing) > 0.0001) {
        float tRing = (dot(gasGiantDir, ringNormal) / (R0 * denomRing));
        if (tRing > 0.0) {
            vec3 hitPointRing = tRing * rayDir;
            vec3 displacement = hitPointRing - (gasGiantDir / R0);
            float rRing = length(displacement);

            if (rRing >= R_in && rRing <= R_out) {
                hitRing = true;
                ringInFront = (tRing < (1.0 / R0));

                float RdotL = dot(displacement, sunDir);
                float shadowOnRing = 1.0;
                if (RdotL < 0.0) {
                    float cylDist = length(displacement - RdotL * sunDir);
                    shadowOnRing = smoothstep(0.95, 1.05, cylDist);
                }

                float normR = (rRing - R_in) / (R_out - R_in);
                float cassini = smoothstep(0.03, 0.065, abs(normR - 0.62));
                float ringlets = (sin(normR * 125.0) * 0.5 + 0.5) * (sin(normR * 38.0) * 0.5 + 0.5);

                float density = (0.42 + 0.48 * ringlets) * cassini;
                float edgeFade = smoothstep(R_in, R_in + 0.04, rRing) * smoothstep(R_out, R_out - 0.04, rRing);
                ringAlpha = density * edgeFade;

                float phaseTerm = 0.65 + 0.35 * pow(abs(dot(rayDir, sunDir)), 2.0);
                vec3 ringIcyColor = mix(vec3(1.0, 0.88, 0.62), vec3(0.85, 0.68, 0.95), normR);
                ringColor = ringIcyColor * shadowOnRing * phaseTerm * 1.25;
            }
        }
    }

    vec3 celestialComposite = vec3(0.0);
    float celestialAlpha = 0.0;

    if (hitPlanet && hitRing) {
        if (ringInFront) {
            celestialComposite = mix(planetColor, ringColor, ringAlpha);
            celestialAlpha = planetAlpha;
        } else {
            celestialComposite = mix(ringColor, planetColor, planetAlpha);
            celestialAlpha = max(planetAlpha, ringAlpha);
        }
    } else if (hitPlanet) {
        celestialComposite = planetColor;
        celestialAlpha = planetAlpha;
    } else if (hitRing) {
        celestialComposite = ringColor;
        celestialAlpha = ringAlpha;
    }

    float finalBlend = celestialAlpha * horizonMask * (1.0 - rain * 0.85);
    return mix(skyColor, celestialComposite, finalBlend);
}

#endif // ALIEN_SKY_GLSL
